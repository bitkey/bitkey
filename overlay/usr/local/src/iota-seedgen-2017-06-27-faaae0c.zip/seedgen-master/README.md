# seedgen

This is a naive seed generator using the [Stanford Javascript Crypto Library](https://github.com/bitwiseshiftleft/sjcl).
