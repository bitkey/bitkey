'use strict';

var balanceDrtv = function() {
	return {
        restrict : "E",
        template : require('./balanceDrtv.html')
  };
};
module.exports = balanceDrtv;
